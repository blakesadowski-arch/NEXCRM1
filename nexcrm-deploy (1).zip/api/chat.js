// ─────────────────────────────────────────────────────────────
//  NexCRM — Serverless AI proxy (Vercel Function)
//
//  Lives at  /api/chat  and forwards requests to the Anthropic API.
//  Your ANTHROPIC_API_KEY is set as an environment variable in the
//  Vercel dashboard and NEVER touches the browser.
//
//  The frontend calls this endpoint; if it ever fails, the pages
//  fall back to their built-in simulated AI, so nothing breaks.
// ─────────────────────────────────────────────────────────────

const MODEL = "claude-opus-4-7";

export default async function handler(req, res) {
  // Only allow POST
  if (req.method !== "POST") {
    res.status(405).json({ error: { message: "Method not allowed" } });
    return;
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    res.status(500).json({ error: { message: "ANTHROPIC_API_KEY not configured" } });
    return;
  }

  try {
    const { messages, max_tokens } = req.body || {};
    if (!messages) {
      res.status(400).json({ error: { message: "messages required" } });
      return;
    }

    const upstream = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: MODEL,
        max_tokens: max_tokens || 900,
        messages,
      }),
    });

    const data = await upstream.json();

    if (!upstream.ok) {
      res.status(upstream.status).json(data);
      return;
    }

    // Return in the exact shape the frontend already expects
    res.status(200).json(data);
  } catch (err) {
    res.status(500).json({ error: { message: err.message } });
  }
}
